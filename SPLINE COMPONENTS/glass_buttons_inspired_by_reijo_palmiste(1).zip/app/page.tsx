import Spline from '@splinetool/react-spline/next';

export default function Home() {
  return (
    <main>
      <Spline
        scene="https://prod.spline.design/tGwxxI359OfBjIJh/scene.splinecode" 
      />
    </main>
  );
}
