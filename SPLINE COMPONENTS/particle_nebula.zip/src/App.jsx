import Spline from '@splinetool/react-spline';

export default function App() {
  return (
    <Spline scene="scene.splinecode" wasmPath="/" />
  );
}