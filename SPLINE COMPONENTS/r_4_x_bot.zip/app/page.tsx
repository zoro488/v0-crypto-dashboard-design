import Spline from '@splinetool/react-spline/next';

export default function Home() {
  return (
    <main>
      <Spline
        scene="https://prod.spline.design/cZAGZ7v6TaqZrhFN/scene.splinecode" 
      />
    </main>
  );
}
