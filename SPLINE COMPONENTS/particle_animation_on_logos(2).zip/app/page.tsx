import Spline from '@splinetool/react-spline/next';

export default function Home() {
  return (
    <main>
      <Spline
        scene="https://prod.spline.design/OmWYX0apclMCltcg/scene.splinecode" 
      />
    </main>
  );
}
