import Spline from '@splinetool/react-spline/next';

export default function Home() {
  return (
    <main>
      <Spline
        scene="https://prod.spline.design/gYoVtVUHgwr8Cc4K/scene.splinecode" 
      />
    </main>
  );
}
