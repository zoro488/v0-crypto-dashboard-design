import Spline from '@splinetool/react-spline/next';

export default function Home() {
  return (
    <main>
      <Spline
        scene="https://prod.spline.design/Umjz4tA2QXT43ljm/scene.splinecode" 
      />
    </main>
  );
}
