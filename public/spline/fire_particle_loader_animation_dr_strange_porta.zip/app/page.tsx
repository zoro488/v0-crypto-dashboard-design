import Spline from '@splinetool/react-spline/next';

export default function Home() {
  return (
    <main>
      <Spline
        scene="https://prod.spline.design/NgWU8fD6towEaxnr/scene.splinecode" 
      />
    </main>
  );
}
