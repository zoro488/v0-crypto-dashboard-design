import Spline from '@splinetool/react-spline/next';

export default function Home() {
  return (
    <main>
      <Spline
        scene="https://prod.spline.design/dH-4EV9KmcymGWUW/scene.splinecode" 
      />
    </main>
  );
}
